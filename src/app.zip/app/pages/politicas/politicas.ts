import { Component } from '@angular/core';

@Component({
  selector: 'app-politicas',
  imports: [],
  templateUrl: './politicas.html',
  styleUrl: './politicas.css',
})
export class Politicas {

}
