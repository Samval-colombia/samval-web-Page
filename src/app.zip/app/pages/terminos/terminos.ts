import { Component } from '@angular/core';

@Component({
  selector: 'app-terminos',
  imports: [],
  templateUrl: './terminos.html',
  styleUrl: './terminos.css',
})
export class Terminos {

}
