export interface Ally {

      id: number,
      titleKey: string,
      descriptionKey:string,
      image: string,
      location: string,
      website? : string
}
